from django.apps import AppConfig


class AuthformappConfig(AppConfig):
    name = 'AuthFormApp'
